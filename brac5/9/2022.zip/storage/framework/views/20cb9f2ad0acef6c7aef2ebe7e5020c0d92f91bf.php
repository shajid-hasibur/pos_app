    	<div class="modal-header">
    		<h2 class="modal-title" id="exampleModalLabel">Update Product Information</h2>
    		<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
    	</div>
    	<div class="modal-body">
    		<?php if(!empty($product->image)): ?>
    		<img src="<?php echo e(asset('/')); ?><?php echo e($product->image); ?>" alt="<?php echo e($product->name); ?>" class="img-rounded" style="width:100px;height:100px;">
    		<?php else: ?>
    		<img src="<?php echo e(asset('/')); ?>public/admin/defaultIcon/no_image.png" alt="No-image" class="img-rounded" style="width:100px;height:100px;">
    		<?php endif; ?>

    		<form method="post" action="<?php echo e(route('admin.product.updateProduct')); ?>" enctype="multipart/form-data">
    			<?php echo csrf_field(); ?>
    			<div class="form-row">
    				<div class="form-group col-md-12">
    					<label>Change Image</label>
    					<input type="file" class="form-control-file" name="image">
    					<input type="hidden" name="id" value="<?php echo e($product->id); ?>">
    				</div>

    				<div class="form-group col-md-6">
    					<label>Name</label>
    					<input type="text" class="form-control" name="name" value="<?php echo e($product->name); ?>">
    				</div>
    				<div class="form-group col-md-6">
    					<label>Alert Quantity</label>
    					<input type="text" class="form-control" name="alert_qty" value="<?php echo e($product->alert_qty); ?>">
    				</div>
    				<div class="form-group col-md-4">
    					<label>Product cost</label>
    					<input type="number" class="form-control" name="purchase_price" value="<?php echo e($product->purchase_price); ?>">
    				</div>
    				<div class="form-group col-md-4">
    					<label>Sell Price</label>
    					<input type="number" class="form-control" name="sell_price" value="<?php echo e($product->sell_price); ?>">
    				</div>
    				<div class="form-group col-md-4">
    					<label>Wholesell Price</label>
    					<input type="number" class="form-control" name="whole_sell" value="<?php echo e($product->whole_sell); ?>">
    				</div>
    				<div class="form-group col-md-6">
    					<label>Unit</label>
    					<select class="form-control" name="unit">
    						<option value="<?php echo e($product->unit); ?>">Change unit</option>
    						<?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    						<option value="<?php echo e($unit->id); ?>"><?php echo e($unit->name); ?></option>

    						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    					</select>

    				</div>
    				<div class="form-group col-md-6">
    					<label>Starting Inventory</label>
    					<input type="number" class="form-control" name="start_inventory" value="<?php echo e($product->start_inventory); ?>">
    				</div>
    				<div class="form-group col-md-12">
    					<label>Description</label>

    					<textarea class="form-control" name="description" rows="3"><?php echo e($product->description); ?></textarea>
    				</div>

    			</div>
    			<div class="form-row">
    				<input type="submit" class="btn btn-primary" style="float:right;" value="Update Product">

    			</div>

    		</form>
    	</div>


<?php /**PATH /home/codetree/public_html/project/gripngrease.com.bd/resources/views/admin/modules/product/editProduct.blade.php ENDPATH**/ ?>