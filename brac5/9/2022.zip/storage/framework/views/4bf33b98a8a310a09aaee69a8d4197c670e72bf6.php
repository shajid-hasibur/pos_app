<?php $__env->startSection('adminTitle'); ?>
Print barcode- Admin Dashboard
<?php $__env->stopSection(); ?>
<?php $__env->startSection('adminContent'); ?>
<div class="col-md-12 mt-5 pt-3 border-bottom">
	<div class="text-dark px-0" >
		<p class="mb-1"><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-home"></i> Dashboard / </a><a href="<?php echo e(route('admin.productList')); ?>">Products / </a><a class="active-slink">Print Barcode</a> <span class="top-date"><?php echo e(date('l, jS F Y')); ?></span></p>

	</div>
</div>

<div class="container-fluid p-3">
	<div class="box">
		<div class="box-header">
			<div class="box-icon-left border-right" style="height:100%">
				


				<p class="btn mt-0 task-icon"><i class="fa fa-barcode"></i></p>
				
			</div>
			<h2 class="blue task-label">Print Barcode/Label</h2>

			<div class="box-icon border-left" style="height:100%">
				<div class="dropdown mt-0">
					

					
					<p class="task-btn text_p_primary text_p_primary" title="Actions">
						<i class="fa fa-th-list"></i>
					</p>
					<div class="task-menu p-2">
						<a class="dropdown-item pl-0" type="button" data-toggle="modal" data-target=".bd-example-modal-lg">
							<i class="fa-fw fa fa-plus-circle"></i> Print Barcode
						</a>

					</div>
					
				</div>
			</div>
		</div>
		<div class="box-content">
			<div class="row">
				<div class="col-lg-12">
					<p class="introtext">Please fill in the information below. The field labels marked with * are required input fields.</p>


					<form method="post" action="<?php echo e(route('admin.product.generateBarcode')); ?>">
						<?php echo csrf_field(); ?>
						<div class="form-row">

							<div class="form-group col-md-6">
								<label>Select Product *</label>
								<select class="custom-select" name="proid">
									<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($product->id); ?>"><?php echo e($product->name); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
							</div>

							<div class="form-group col-md-6">
								<label>Enter Barcode Quantity *</label>
								<input type="text" class="form-control" name="qty" placeholder="Enter Quantity">
							</div>
                           <div class="form-group col-md-12">
                              <div class="form-check form-check-inline">
							  <input class="form-check-input" type="checkbox" name="siteName" value="siteName">
							  <label class="form-check-label" for="inlineCheckbox1">Site Name</label>
							</div>
							<div class="form-check form-check-inline">
							  <input class="form-check-input" type="checkbox" name="productname" value="productName">
							  <label class="form-check-label" for="inlineCheckbox1">Product Name</label>
							</div>
							<div class="form-check form-check-inline">
							  <input class="form-check-input" type="checkbox" name="sellPrice" value="sellPrice">
							  <label class="form-check-label" for="inlineCheckbox1">Sell Price</label>
							</div>
							<div class="form-check form-check-inline">
							  <input class="form-check-input" type="checkbox" name="label" value="label">
							  <label class="form-check-label" for="inlineCheckbox1">Label</label>
							</div>
						  </div>

							<div class="form-group col-12">
								<input type="submit" class="btn bg_p_primary" value="Generate" style="border-radius:0px;">
							</div>
						</div>
					</form>
					
					
				</div>
			</div>
		</div>
	</div>

</div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.adminmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp2\htdocs\brac_24_8_2022_h\resources\views/admin/modules/product/printBarcode.blade.php ENDPATH**/ ?>