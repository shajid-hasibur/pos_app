
<?php $__env->startSection('adminTitle'); ?>
<?php echo e($supplierrInfo->name); ?> -Supplier Details
<?php $__env->stopSection(); ?>
<?php $__env->startSection('adminContent'); ?>
<style>
	p{
		margin-bottom:0px;
	}
	}
	.upper-action-btn{
		 margin-top:-8px;margin-left: 30px;border-radius: 0px;padding: 2px 20px;cursor:pointer;
	}
</style>
<div class="col-md-12 mt-5 pt-3 border-bottom">
	<div class="text-dark px-0" >
		<p class="mb-1"><a href="<?php echo e(route('admin.dashboard')); ?>" ><i class="fa fa-home"></i> Dashboard /</a><a href="<?php echo e(route('admin.supplierList')); ?>">Suppliers /</a><a class="active-slink">Supplier Details</a><span class="top-date"><?php echo e(date('l, jS F Y')); ?></span></p>

	</div>
</div>

<div class="container-fluid p-3">
	                                                                               
   <div class="row p-1">
    <div class="col-2">
    	<center>
    	<?php if(!empty($supplierrInfo->image)): ?>
    		<img src="<?php echo e(asset('/')); ?><?php echo e($supplierrInfo->image); ?>" alt="<?php echo e($supplierrInfo->name); ?>" class="img-rounded" style="width:100px;height:100px;">
    		<?php else: ?>
    		<img src="<?php echo e(asset('/')); ?>public/admin/defaultIcon/user.png" alt="No-image" class="img-rounded" style="width:100px;height:100px;">
    		<?php endif; ?>
    	
    </center>
    </div>
        <div class="col-5 col-xs-12">
    	<h3 style="float: left;margin-bottom: 0px;font-weight:bold">Basic Information</h3>
    	<p class="btn btn-info edit-info" style=" margin-top:-8px;margin-left: 30px;border-radius: 0px;padding: 2px 20px;cursor:pointer;" data-supplierid="<?php echo e($supplierrInfo->id); ?>">Edit</p>
    	<hr class="mt-0">
    	<p>Name: <?php echo e($supplierrInfo->name); ?></p>
    	<p>Mobile: <?php echo e($supplierrInfo->mobile); ?></p>
    	<?php if(!empty($supplierrInfo->email)): ?>
    	<p>Email: <?php echo e($supplierrInfo->email); ?></p>
    	<?php endif; ?>
    	<p>Company: <?php echo e($supplierrInfo->company); ?></p>
    </div>
    <div class="col-5 col-xs-12">
    	<h3><b>Purchase Information</b></h3>
    	<hr class="mt-0">
    	<p>Starting Balance: ৳<?php echo e(number_format($supplierrInfo->start_balance)); ?></p>
    	<p>Total Purchase: ৳<?php echo e(number_format($totalpurchase)); ?></p>
    	<p>Total Discount: ৳<?php echo e(number_format($totalDiscount)); ?></p>
    	<p>Total Due: ৳<?php echo e(number_format($totalDue+$supplierrInfo->start_balance)); ?></p>
    </div>
   	<div class="col-12 mt-3">
   		<h3 class="mb-0"><b>Purchase History</b></h3>
   		<hr class="mt-0">
   					<table class="table table-bordered table-hover">
						<thead class="bg_p_primary">
							<tr>
								<th class="font-weight-bold" scope="col">#</th>
								<th class="font-weight-bold" scope="col">Date</th>
								<th class="font-weight-bold" scope="col">Reference No</th>
								<th class="font-weight-bold" scope="col">Purchase Status</th>
								<th class="font-weight-bold" scope="col">Grand Total</th>
								<th class="font-weight-bold" scope="col">Paid</th>
								<th class="font-weight-bold" scope="col">Discount</th>
								<th class="font-weight-bold" scope="col">Balance</th>
								<th class="font-weight-bold" scope="col">Payment Status</th>
								
								<th class="font-weight-bold" scope="col">Actions</th>

							</tr>
						</thead>
						<tbody>
							<?php $counter=0;?>
                           <?php $__currentLoopData = $purchaseHistory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <?php $counter++;?>
							<tr>
								<td><?php echo e($counter); ?></td>
								<td><?php echo e($purchase->purchase_date); ?></td>
								<td><?php echo e($purchase->reference); ?></td>
								<td>
									<?php if($purchase->is_received==1): ?>
									<p class="badge  bg_secondary_teal">Received</p>
									<?php else: ?>
									<p class="badge badge-danger">Pending</p>
									<?php endif; ?>
								</td>
								<td><?php echo e(number_format($purchase->grand_total)); ?></td>
							
								<td><?php echo e(number_format($purchase->paid_amount)); ?></td>
								<td><?php echo e(number_format($purchase->discount)); ?></td>
								<td>
                                
								<?php echo e(number_format($purchase->due)); ?>

							  </td>
								
								<td>
									<?php if($purchase->due >0): ?>
									<p class="badge badge-danger">Due</p>
									<?php else: ?>
                                  <p class="badge  bg_secondary_teal">Paid</p>
									<?php endif; ?>
								</td>
								<td style="width:120px;">
									<div class="dropdown" style="width:90px;float:right;">
									  <p class="action-btn  purchaseDetails"  data-purchase_id="<?php echo e($purchase->id); ?>">
									   Details
									  </p>
									 
									</div>
							    </td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							
							</tbody>
						</table>

   		
   	</div>
   </div>
</div>
<!-- Modal -->
<div class="modal fade bd-example-modal-lg purchase_details" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content p-3">

    </div>
  </div>
</div>
<script>
	$(document).ready(function(){
       $(".purchaseDetails").click(function(){
      var purchase_id=$(this).data('purchase_id');
      //ajax
		 $.ajax({
		   headers: {
		    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
		  },
		  url:"<?php echo e(route('admin.purchase.purchaseDetails')); ?>",
		  type:"POST",
		  data:{'purchase_id':purchase_id},
		        //dataType:'json',
		        success:function(data){
		        	$(".modal-content").html(data);
		          $('.purchase_details').modal('show'); 
		        },
		        error:function(){
		          toastr.error("Something went Wrong, Please Try again.");
		        }
		      });

		  //end ajax
		       });
       //edit supplier  infomation
       $(".edit-info").click(function(){
         var supplierid=$(this).data('supplierid');
        //ajax
		 $.ajax({
		   headers: {
		    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
		  },
		  url:"<?php echo e(route('admin.supplier.supplierInfo')); ?>",
		  type:"POST",
		  data:{'supplierid':supplierid},
		        //dataType:'json',
		        success:function(data){
		        	$(".modal-content").html(data);
		          $('.purchase_details').modal('show'); 
		        },
		        error:function(){
		          toastr.error("Something went Wrong, Please Try again.");
		        }
		      });

		  //end ajax
       });
	});
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.adminmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/codetree/public_html/gripngrease.com.bd/resources/views/admin/modules/people/supplier/supplierDetails.blade.php ENDPATH**/ ?>