

<div class="modal-header">
        <h2 class="modal-title" id="exampleModalLabel">Product Information</h2>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
       <div class="modal-body">                                          
   <div class="row p-1">
    <div class="col-2">
    	<center>
    		<?php if(!empty($productInfo->image)): ?>
    		<img src="<?php echo e(asset('/')); ?><?php echo e($productInfo->image); ?>" alt="<?php echo e($productInfo->name); ?>" class="img-rounded" style="width:100px;height:100px;">
    		<?php else: ?>
    		<img src="<?php echo e(asset('/')); ?>public/admin/defaultIcon/no_image.png" alt="No-image" class="img-rounded" style="width:100px;height:100px;">
    		<?php endif; ?>
    	
    </center>
    </div>
    <div class="col-5 col-xs-12">
    	<h3><b>Basic Information</b></h3>
    	<hr class="mt-0">
    	<p class="mb-0">Name: <?php echo e($productInfo->name); ?></p>
    	<p class="mb-0">Code: <?php echo e($productInfo->code); ?></p>
    	<p class="mb-0">Category: <?php echo e($productInfo->catName); ?></p>
    	<p class="mb-0">Brand: <?php echo e($productInfo->bName); ?></p>
    	<p class="mb-0">Alert Quantity: <?php echo e($productInfo->alert_qty); ?> <?php echo e($productInfo->uName); ?></p>
        <hr>
      <p><?php echo e($productInfo->description); ?></p>
    	
    </div>
    <div class="col-5 col-xs-12">
    	<h3><b>Purchase / Sales  Information</b></h3>
    	
    	<hr class="mt-0">
    	<p class="mb-0">Purchase Price: ৳<?php echo e(number_format($productInfo->purchase_price)); ?></p>
    	<p class="mb-0">Sell Price: ৳<?php echo e(number_format($productInfo->sell_price)); ?></p>
    	<p class="mb-0">Whole Sell Price: ৳<?php echo e(number_format($productInfo->whole_sell)); ?></p>
    	<p class="mb-0">Start Inventory: <?php echo e(number_format($productInfo->start_inventory)); ?> <?php echo e($productInfo->uName); ?></p>
    	<p class="mb-0">Total Purchase: <?php echo e(number_format($totalPurchase)); ?> <?php echo e($productInfo->uName); ?></p>
    	<p class="mb-0">Total Sale: <?php echo e(number_format($totalsale)); ?> <?php echo e($productInfo->uName); ?></p>
    	<p class="mb-0 badge  bg_secondary_teal">In Stock: <?php echo e(number_format($inStock)); ?> <?php echo e($productInfo->uName); ?></p>
    	
    </div>

   </div>
</div>
</div>

<?php /**PATH /home/codetree/public_html/gripngrease.com.bd/resources/views/admin/modules/product/productDetails.blade.php ENDPATH**/ ?>