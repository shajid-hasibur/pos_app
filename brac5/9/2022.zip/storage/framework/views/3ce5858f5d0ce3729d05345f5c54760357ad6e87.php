<div class="hero-wrap" style="position:relative;top:-23px">
      <div class="home-slider owl-carousel">
        <div class="slider-item" style="background-image:url(public/frontEnd/images/bg-1.jpg);">
          <div class="overlay"></div>
          <div class="container">
            <div class="row no-gutters slider-text align-items-center justify-content-start">
              <div class="col-md-6 ftco-animate">
                <div class="text w-100">
                  <h2>We care about your car</h2>
                
                  <p><a href="#" class="btn btn-primary">Click Here</a></p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="slider-item" style="background-image:url(public/frontEnd/images/bg-2.jpg);">
          <div class="overlay"></div>
          <div class="container">
            <div class="row no-gutters slider-text align-items-center justify-content-start">
              <div class="col-md-6 ftco-animate">
                <div class="text w-100">
                  <h2>We care about your car</h2>
                
                  <p><a href="#" class="btn btn-primary">Click Here</a></p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div><?php /**PATH /home/codetree/public_html/gripngrease.com.bd/resources/views/frontEnd/include/banner.blade.php ENDPATH**/ ?>