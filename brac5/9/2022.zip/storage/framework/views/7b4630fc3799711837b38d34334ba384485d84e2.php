
<?php $__env->startSection('adminTitle'); ?>
Permission List- Admin Dashboard
<?php $__env->stopSection(); ?>
<?php $__env->startSection('adminContent'); ?>
<div class="col-md-12 mt-5 pt-3 border-bottom">
	<div class="text-dark px-0" >
		<p class="mb-1"><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-home"></i> Dashboard / </a><a href="<?php echo e(route('admin.userList')); ?>">Users / </a><a  class="active-slink">Permissions</a><span class="top-date"><?php echo e(date('l, jS F Y')); ?></span></p>

	</div>
</div>

<div class="container-fluid p-3">
	<div class="box">
		<div class="box-header">
			<div class="box-icon-left border-right" style="height:100%">
				
					

					<p class="btn mt-0 task-icon"><i class="fa fa-users"></i></p>
				
			</div>
			<h2 class="blue task-label">Permissions</h2>

			<div class="box-icon border-left" style="height:100%">
				<div class="dropdown mt-0">
					

					
						<p class="task-btn text_p_primary" title="Actions">
							<i class="fa fa-th-list"></i>
						</p>
						<div class="task-menu p-2">
							
							
						</div>
					
				</div>
			</div>
		</div>
		<div class="box-content">
			<div class="row">
				<div class="col-lg-12">
					<p class="introtext">Please use the table below to navigate or filter the results. You can download the table as excel and pdf.</p>
					<table class="table table-bordered table-hover">
						<thead class="bg_p_primary">
							<tr>
								<th class="font-weight-bold" scope="col">#</th>
								<th class="font-weight-bold" scope="col">Permission Name</th>
								<th class="font-weight-bold" scope="col">Guard Name</th>
								
								<th class="font-weight-bold" scope="col">Actions</th>

							</tr>
						</thead>
						<tbody>
							<?php $counter=0;?>
                            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $counter++;?>
							<tr>
								<td><?php echo e($counter); ?></td>
								<td><?php echo e($permission->name); ?></td>
								<td><?php echo e($permission->guard_name); ?></td>
								
								<td style="width:120px;">
									<div class="dropdown" style="width:90px;float:right;">
									  <p class="action-btn dropdown-toggle" data-toggle="dropdown" aria-haspopup="true">
									   Action
									  </button>
									  <div class="dropdown-menu action-menu">
									  	 <a class="dropdown-item" href=""> <i class="fa-fw fa fa-eye"></i> View</a>
									    <a class="dropdown-item" href="#"> <i class="fa-fw fa fa-trash"></i> Delete</a>
									   
									    <a class="dropdown-item" href="#"> <i class="fa-fw fa fa-edit"></i> Edit</a>
									  </div>
									</div>
							    </td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</tbody>
						</table>
						
				</div>
			</div>
		</div>
	</div>

</div>

</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.adminmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/codetree/public_html/gripngrease.com.bd/resources/views/admin/modules/people/users/permissionsList.blade.php ENDPATH**/ ?>