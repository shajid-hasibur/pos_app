<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA_Compatible" content="ie=edge">
  <link rel="icon" type="image/x-icon" href="<?php echo e(asset('public/frontEnd/images/brac_only_logo.png')); ?>"> 
    <!--bootstrap-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/')); ?>public/admin/asset/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/')); ?>public/admin/asset/css/all.min.css">
    <!--fontawesome-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/')); ?>public/admin/asset/css/fontawesome.min.css">
    <!--customised css file-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/')); ?>public/admin/asset/css/style.css">
    <title>Login -Admin Panel</title>
</head>
<body class="form-body" style="background-image:url('public/frontEnd/images/b2.jpg');background-repeat: no-repeat;background-size: cover; ">
	<div class="container-fluid">
		<div class="row mt-5">
			
			<div class="offset-md-4 col-md-4 col-sm-4 col-xs-12 mt-5">
               <center style="background-color: white;">
               <img  class="img-fluid w-50" src="<?php echo e(asset('public/frontEnd/images/brac_full_logo.png')); ?>">
               <center>
                <form class="form-container" style="padding:35px 60px;margin-top:0px;background: transparent;" method="POST" action="<?php echo e(route('admin.login.submit')); ?>">
                  
                  

                  <?php echo e(csrf_field()); ?>

                  <?php if(Session::has('message')): ?>
                  <p class="badge badge-danger" style="color:red;background-color: white;"><?php echo e(Session::get('message')); ?></p>
                  <?php endif; ?>
                  <?php if($errors->any()): ?>
                  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <p class="badge badge-danger" style="color:red;background-color: white;"><?php echo e($error); ?></p>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
                  
                  <div class="input-group" id="input-box">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="far fa-envelope"></i></span>
                    </div>
                    <input class="form-control" type="email" name="email" value="<?php echo e(old('email')); ?>" placeholder="Email Address">
                    

                </div>
                <div class="input-group mt-3" id="input-box">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fas fa-lock"></i></span>
                    </div>
                    <input class="form-control" type="password" name="password" placeholder="Password">
                </div>

                <button type="submit" class="btn  bg_secondary_teal btn-block mt-3" style="border-radius:0px;">Login</button>
            </form>
        </div>

    </div>
</div>



<!--js file-->
<script src="<?php echo e(asset('/')); ?>public/admin/asset/js/jquery-3.4.1.min.js"></script>
<script src="<?php echo e(asset('/')); ?>public/admin/asset/js/popper.min.js"></script>
<script src="<?php echo e(asset('/')); ?>public/admin/asset/js/bootstrap.min.js"></script>
<script src="<?php echo e(asset('/')); ?>public/admin/asset/js/all.min.js"></script>
<script src="<?php echo e(asset('/')); ?>public/admin/asset/js/main.js"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\brac_22_8_2022\resources\views/admin/auth/login.blade.php ENDPATH**/ ?>