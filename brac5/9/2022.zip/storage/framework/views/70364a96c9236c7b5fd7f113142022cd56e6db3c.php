<?php $__env->startSection('adminTitle'); ?>
Sales Details
<?php $__env->stopSection(); ?>
<?php $__env->startSection('posContent'); ?>
<div class="row mt-5">
  <div class="offset-4 col-4 mt-5 p-0">
    <a href="#" class="btn  bg_secondary_teal col-12 " style="color:white;font-size:20px;border-radius: 0px;" onclick="printContent('print')">PRINT</a>
    <a href="<?php echo e(route('admin.posModule')); ?>"class="btn btn-info col-12 mt-1" style="color:white;font-size:20px;border-radius: 0px;">BACK TO POS</a>
    
    
  </div>
  <div class="offset-4 col-4 mt-0 p-4 mt-1" style="border:1px dotted gray" id="print">
        <style>
        .bill-p{
          margin-bottom: 0px;
          font-size:14px;
          font-weight: 500;
        }
        .company_name{
          margin-bottom: 0px;
          font-weight: 500;
          font-size:25px;
        }
      </style>
       <div style="text-align: center;">
         <h1 class="company_name"><?php echo e($system->siteName); ?></h1>
         <p class="bill-p"><?php echo e($system->siteEmail); ?></p>
         <p class="bill-p"><b><?php echo e($system->sitePhone); ?></b></p>
         
       </div>
       <div class="row p-0 m-0 mt-2 mb-2">
        <div class="col-6 pl-0">
          
        <p class="bill-p"><b>BILL TO</b></p>
         <p class="bill-p"><?php echo e($billInfo->name); ?></p>
         <p class="bill-p"><?php echo e($billInfo->mobile); ?></p>
        </div>
        <div class="col-6 pr-0" style="text-align: right;">
          <p class="bill-p">Invoice#<?php echo e($billInfo->code); ?></p>
          <p class="bill-p">Date: <?php echo e($billInfo->sales_date); ?></p>
        </div>
         
       </div>
       
       <div>
         <table class="table table-bordered">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Item</th>
      <th scope="col">Qty</th>
      <th scope="col">Price</th>
      <th scope="col">Total</th>
    </tr>
  </thead>
  <tbody>
     <?php
        $counter=0;
        ?>
        <?php $__currentLoopData = $billProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
        $counter++;
       
        ?>
    <tr>
      <td><?php echo e($counter); ?></td>
      <td><?php echo e($product->name); ?></td>
      <td><?php echo e($product->qty); ?></td>
      <td><?php echo e($product->unit_price); ?></td>
      <td style="text-align: right;"><?php echo e(number_format($product->subtotal,2)); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td colspan="4">Total</td>
      <?php
      $total=($billInfo->grand_total+$billInfo->discount)-$billInfo->tax;
      ?>
      <td style="text-align: right;"><?php echo e(number_format($total,2)); ?></td>
    </tr>
    <tr>
      <td colspan="4">Tax</td>
      <td style="text-align: right;"><?php echo e(number_format($billInfo->tax,2)); ?></td>
    </tr>
    <tr>
      <td colspan="4">Discount</td>
      <td style="text-align: right;"><?php echo e(number_format($billInfo->discount,2)); ?></td>
    </tr>
    <tr>
      <td colspan="4">Grand Total</td>
      <td style="text-align: right;"><?php echo e(number_format($billInfo->grand_total,2)); ?></td>
    </tr>
     <tr>
      <td colspan="4">Paid</td>
      <td style="text-align: right;"><?php echo e(number_format($billInfo->paid_amount,2)); ?></td>
    </tr>
     <tr>
      <?php if($billInfo->due < 0): ?>
      <td colspan="4">Change</td>
      <?php 
      $b = $billInfo->due;
      $b = -1 * $b;
      ?>
      <td style="text-align: right;"><?php echo e(number_format($b,2)); ?></td>
      <?php else: ?>
      <td colspan="4">Due</td>
      <td style="text-align: right;"><?php echo e(number_format($billInfo->due,2)); ?></td>
      <?php endif; ?>
    </tr>
   
  </tbody>
</table>
<br>
       </div>

       <div>
         <p class="bill_p" style="font-size: 12px;">Thanks for shopping with us</p>
         <br>
       </div>
       <div style="text-align: center;">
         <p class="bill_p" style="font-size: 12px;font-weight: bold;">Pewered By www.codetreebd.com</p>
       </div>
     
  </div>
  <div class="offset-4 col-4 mt-0 mb-5 p-0">
    
    <a href="<?php echo e(route('admin.pos.deleteSale',$billInfo->id)); ?>"class="btn btn-danger col-12 mt-1" style="color:white;font-size:20px;border-radius: 0px;">DELETE</a>
    
    
  </div>
  
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.modules.pos.layout.posMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp2\htdocs\brac_24_8_2022_h\resources\views/admin/modules/pos/layout/billview.blade.php ENDPATH**/ ?>