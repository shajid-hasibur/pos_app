 <?php if(!$productList->isEmpty()): ?>
 <?php $__currentLoopData = $productList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <button class="btn-prni btn-default product pos-tip search_item" title="<?php echo e($products->name); ?>" data-searech_pro_id_="<?php echo e($products->id); ?>">
    <?php if(!empty($products->image)): ?>
    <img src="<?php echo e(asset('/')); ?><?php echo e($products->image); ?>" alt="<?php echo e($products->name); ?>" class="img-rounded">
    <?php else: ?>
    <img src="<?php echo e(asset('/')); ?>public/admin/defaultIcon/no_image.png" alt="<?php echo e($products->name); ?>" class="img-rounded">
    <?php endif; ?>
    <p class=""><?php echo e($products->name); ?></p>
  </button>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
  <?php else: ?>
  <p>No Product Avaiable</p>
  <?php endif; ?>
  <script>
  	$(document).ready(function(){
      $(".search_item").click(function(){
      	
      	var search_id=$(this).data('searech_pro_id_');
     
 //ajax
 $.ajax({
   headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
  },
  url:"<?php echo e(route('admin.pos.addToCart')); ?>",
  type:"POST",
  data:{'pro_id':search_id},
        //dataType:'json',
        success:function(data){
          $("#posProduct").val('');
          $("#print").html(data);
        },
        error:function(){
          toastr.error("Something went Wrong, Please Try again.");
        }
      })
  //end ajax
  	});
  });

  </script><?php /**PATH /home/codetree/public_html/gripngrease.com.bd/resources/views/admin/modules/pos/searchProduct.blade.php ENDPATH**/ ?>