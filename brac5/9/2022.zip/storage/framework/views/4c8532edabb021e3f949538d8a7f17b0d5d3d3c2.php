      <div class="modal-header">
        <h2 class="modal-title" id="exampleModalLabel">Profit/Loss</h2>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
      <div class="modal-body">
       <table class="table">
  <thead>
    
  </thead>
  <tbody>
    <tr>
      
      <td>Total Sales</td>
      <td style="text-align: right;"><?php echo e(number_format($totalSale)); ?></td>
    </tr>
    <tr>
      
      <td>Product's Cost</td>
      <td style="text-align: right;"><?php echo e(number_format($totalProductCost)); ?></td>
    </tr>
    <tr>
     
      <td>Expense</td>
      <td style="text-align: right;"><?php echo e(number_format($totalExpense)); ?></td>
    </tr>
    <tr>
     
      <td><b>Profit</b></td>
      <td style="text-align: right;" ><b><?php echo e(number_format($profit)); ?></b></td>
    </tr>
  </tbody>
</table>
      </div><?php /**PATH D:\xampp2\htdocs\brac_24_8_2022_h\resources\views/admin/modules/pos/profitlossContainer.blade.php ENDPATH**/ ?>