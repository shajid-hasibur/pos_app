


<?php $__env->startSection('title'); ?>
<?php echo e($webpros->name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
 <section class="ftco-section">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-md-7 heading-section text-center ftco-animate">
           <!-- <span class="subheading"><?php echo e($webpros->name); ?></span>-->
            <h2><?php echo e($webpros->name); ?></h2>
          </div>
        </div>
        <div class="row d-flex">
         
        <div class="col-md-5">
          <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-100" src="<?php echo e(asset('/')); ?><?php echo e($webpros->image); ?>" alt="First slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="<?php echo e(asset('/')); ?><?php echo e($webpros->image1); ?>" alt="Second slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="<?php echo e(asset('/')); ?><?php echo e($webpros->image2); ?>" alt="Third slide">
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true" style=" color:black;"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true" style=" color:black;"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
        </div>
        <!--description face-->
        <div class="col-md-7">
          <div class="card">
            <div class="card-body">
              <h6 class="card-text"><b>Price:</b> <?php echo e($webpros->price); ?></h6>
              <h6 class="card-text"><b>Brand:</b> <?php echo e($webpros->brand); ?></h6>
              <h6 class="card-text"><b>Condition:</b> <?php echo e($webpros->condition); ?></h6>
                  <h6 class="card-text"><b>Availaable:</b>
                  <?php if($webpros->status == 1): ?> 
                   <b class="text-success">Yes</b>
                   <?php else: ?>
                   <b class="text-info">No</b>
                   <?php endif; ?>
                  </h6>
                  <p class="card-text"><?php echo $webpros->description; ?></p>
            </div>
      </div>
          
        </div>
        <!--description face-->
         
         
        </div>
      </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/codetree/public_html/gripngrease.com.bd/resources/views/frontEnd/singlepro.blade.php ENDPATH**/ ?>