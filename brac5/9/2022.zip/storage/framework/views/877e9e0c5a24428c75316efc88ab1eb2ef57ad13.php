
<?php $__env->startSection('adminTitle'); ?>
<?php echo e($admin->first_name); ?>-Dashboard
<?php $__env->stopSection(); ?>
<?php $__env->startSection('adminContent'); ?>
<style>
	p{
		margin-bottom:0px;
	}
	.upper-action-btn{
		 margin-top:-8px;margin-left: 30px;border-radius: 0px;padding: 2px 20px;cursor:pointer;
	}
</style>
<div class="col-md-12 mt-5 pt-3 border-bottom">
	<div class="text-dark px-0" >
		<p class="mb-1"><a href="<?php echo e(route('admin.dashboard')); ?>" ><i class="fa fa-home"></i> Dashboard / </a><a class="active-slink">My Profile</a><span class="top-date"><?php echo e(date('l, jS F Y')); ?></span></p>

	</div>
</div>

<div class="container-fluid p-3">
	                                                                               
   <div class="row p-1">
    <div class="col-2">
    	<center>
    		<?php if(!empty($admin->image)): ?>
    		<img src="<?php echo e(asset('/')); ?><?php echo e($admin->image); ?>" alt="<?php echo e($admin->first_name); ?>" class="img-rounded" style="width:100px;height:100px;">
    		<?php else: ?>
    		<img src="<?php echo e(asset('/')); ?>public/admin/defaultIcon/user.png" alt="No-image" class="img-rounded" style="width:100px;height:100px;">
    		<?php endif; ?>
    	
    </center>
    </div>
    <div class="col-5 col-xs-12">
    	<h3 style="float: left;margin-bottom: 0px;font-weight: bold;">Basic Information</h3>
    	<p class="btn btn-info edit-info upper-action-btn" data-customerId="<?php echo e($admin->id); ?>">Edit</p>
    	<p class="btn btn-info update-password upper-action-btn" data-customerId="<?php echo e($admin->id); ?>">Update Password</p>
    	<hr class="mt-0">
    	<p>First Name: <?php echo e($admin->first_name); ?></p>
    	<p>Last Name: <?php echo e($admin->last_name); ?></p>
    	<p>Email: <?php echo e($admin->email); ?></p>
    	<p>Mobile: <?php echo e($admin->mobile); ?></p>
    	<p>Username: <?php echo e($admin->username); ?></p>
    	
    </div>
    <div class="col-5 col-xs-12">
    	
    </div>

   </div>
</div>
<!-- Modal -->
<div class="modal fade bd-example-modal-lg updateModal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content p-3">
    	<div class="modal-header">
        <h2 class="modal-title" id="exampleModalLabel">Update Basic Info</h2>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
       <div class="modal-body">
         	<?php if(!empty($admin->image)): ?>
    		<img src="<?php echo e(asset('/')); ?><?php echo e($admin->image); ?>" alt="<?php echo e($admin->name); ?>" class="img-rounded" style="width:100px;height:100px;">
    		<?php else: ?>
    		<img src="<?php echo e(asset('/')); ?>public/admin/defaultIcon/user.png" alt="No-image" class="img-rounded" style="width:100px;height:100px;">
    		<?php endif; ?>

        	<form method="post" action="<?php echo e(route('admin.updateProfile')); ?>" enctype="multipart/form-data">
					<?php echo csrf_field(); ?>
				  <div class="form-row">
				   <div class="form-group col-md-12">
				      <label>Change Image</label>
				       <input type="file" class="form-control-file" name="image">
				       
				    </div>
				    <div class="form-group col-md-6">
				      <label>First</label>
				       <input type="text" class="form-control" name="first_name" value="<?php echo e($admin->first_name); ?>">
				      
				    </div>
				    <div class="form-group col-md-6">
				      <label>Last Name</label>
				       <input type="text" class="form-control" name="last_name" value="<?php echo e($admin->last_name); ?>">
				    </div>
				    <div class="form-group col-md-6">
				      <label>Email</label>
				       <input type="email" class="form-control" name="email" value="<?php echo e($admin->email); ?>">
				    </div>
				     <div class="form-group col-md-6">
				      <label>Mobile</label>
				       <input type="text" class="form-control" name="mobile" value="<?php echo e($admin->mobile); ?>">
				    </div>
				     <div class="form-group col-md-6">
				      <label>Username</label>
				       <input type="text" class="form-control" name="username" value="<?php echo e($admin->username); ?>">
				    </div>
				    

				  </div>
				  <div class="form-row">
				  	<input type="submit" class="btn btn-primary" style="float:right;" value="Update Profile">
        
				  </div>
				
       </form>
   </div>
        
         
    
    </div>
  </div>
</div>
<div class="modal fade bd-example-modal-lg updatepassword" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content p-3">
    	<div class="modal-header">
        <h2 class="modal-title" id="exampleModalLabel">Update Password</h2>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
       <div class="modal-body">
         	
        	<form method="post" action="<?php echo e(route('admin.updatepassword')); ?>" enctype="multipart/form-data">
					<?php echo csrf_field(); ?>
				  <div class="form-row">
				   
				    <div class="form-group col-md-12">
				      <label>Old Password</label>
				       <input type="password" class="form-control" name="old_password" >
				    </div>
				     <div class="form-group col-md-12">
				      <label>New Password</label>
				       <input type="password" class="form-control" name="password" >
				    </div>
				     <div class="form-group col-md-12">
				      <label>Confirm Password</label>
				       <input type="password" class="form-control" name="password_confirmation">
				    </div>
				    

				  </div>
				  <div class="form-row">
				  	<input type="submit" class="btn btn-primary" style="float:right;" value="Update Password">
        
				  </div>
				
       </form>
   </div>
        
         
    
    </div>
  </div>
</div>
<script>
	$(document).ready(function(){
      
       //edit customer id
       $(".edit-info").click(function(){
          $('.updateModal').modal('show'); 
        
       });
        //edit customer id
       $(".update-password").click(function(){
          $('.updatepassword').modal('show'); 
        
       });
	});
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.adminmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/codetree/public_html/gripngrease.com.bd/resources/views/admin/modules/setting/profile/profile.blade.php ENDPATH**/ ?>