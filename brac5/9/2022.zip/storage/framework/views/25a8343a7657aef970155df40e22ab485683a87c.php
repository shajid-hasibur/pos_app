
      <div class="modal-header">
        <h2 class="modal-title" id="exampleModalLabel">Update Supplier Info</h2>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
       <div class="modal-body">
        <?php if(!empty($supplierInfo->image)): ?>
        <img src="<?php echo e(asset('/')); ?><?php echo e($supplierInfo->image); ?>" alt="<?php echo e($supplierInfo->name); ?>" class="img-rounded" style="width:100px;height:100px;">
        <?php else: ?>
        <img src="<?php echo e(asset('/')); ?>public/admin/defaultIcon/user.png" alt="No-image" class="img-rounded" style="width:100px;height:100px;">
        <?php endif; ?>

        <form method="post" action="<?php echo e(route('admin.supplier.updateSupplier')); ?>" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <div class="form-row pt-0 pb-0 px-2">
              <div class="form-group col-md-12">
              <label>Change Image</label>
               <input type="file" class="form-control-file" name="image">
               <input type="hidden" name="id" value="<?php echo e($supplierInfo->id); ?>">
               
            </div>
             <div class="form-group col-md-6">
              <label for="inputPassword4">Company</label>
               <input type="text" class="form-control" name="company" value="<?php echo e($supplierInfo->company); ?>">
            </div>
            <div class="form-group col-md-6">
              <label for="inputPassword4">Mobile *</label>
               <input type="text" class="form-control" name="mobile"value="<?php echo e($supplierInfo->mobile); ?>">
            </div>
            <div class="form-group col-md-6">
              <label for="inputPassword4">Name *</label>
               <input type="text" class="form-control" name="name" value="<?php echo e($supplierInfo->name); ?>">
            </div>
            <div class="form-group col-md-6">
              <label for="inputPassword4">Email Address</label>
               <input type="email" class="form-control" name="email" value="<?php echo e($supplierInfo->email); ?>">
            </div>
            <div class="form-group col-md-6">
              <label for="inputPassword4">City</label>
               <input type="text" class="form-control" name="city" value="<?php echo e($supplierInfo->city); ?>">
            </div>
            <div class="form-group col-md-6">
              <label for="inputPassword4">Postal Code</label>
               <input type="text" class="form-control" name="postal_code" value="<?php echo e($supplierInfo->postal_code); ?>">
            </div>
            <div class="form-group col-md-12">
              <label for="inputPassword4">Address</label>
               <textarea class="form-control" name="address" rows="3"><?php echo e($supplierInfo->address); ?></textarea>
            </div>


            <div class="form-group">
            <input type="submit" class="btn btn-primary" value="Update Supplier">
          </div>
          </div>
        </form>

        </div>
    
        
      </div>
        
    </div>  
      <?php /**PATH /home/codetree/public_html/gripngrease.com.bd/resources/views/admin/modules/people/supplier/editSupplier.blade.php ENDPATH**/ ?>