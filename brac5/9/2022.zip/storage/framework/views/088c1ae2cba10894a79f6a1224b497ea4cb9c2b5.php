
<?php $__env->startSection('adminTitle'); ?>
Add New Product- Admin Dashboard
<?php $__env->stopSection(); ?>
<?php $__env->startSection('adminContent'); ?>
<style>
	label{
		font-weight: bold;
	}
	input['text']{
		border-radius: 0px;
	}
</style>
<div class="col-md-12 mt-5 pt-3 border-bottom">
	<div class="text-dark px-0" >
		<p class="mb-1"><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-home"></i> Dashboard / </a><a href="<?php echo e(route('admin.productList')); ?>">Products / </a><a class="active-slink">Product Add</a> <span class="top-date"><?php echo e(date('l, jS F Y')); ?></span></p>

	</div>
</div>

<div class="container-fluid p-3">
	<div class="box">
		<div class="box-header">
			<div class="box-icon-left border-right" style="height:100%">
				


				<p class="btn mt-0 task-icon"><i class="fa fa-barcode"></i></p>
				
			</div>
			<h2 class="blue task-label">Add New Product</h2>

			<div class="box-icon border-left" style="height:100%">
				<div class="dropdown mt-0">
					

					
					<p class="task-btn text_p_primary" title="Actions">
						<i class="fa fa-th-list"></i>
					</button>
					<div class="task-menu p-2">
						<a class="dropdown-item pl-0" type="button" data-toggle="modal" data-target=".bd-example-modal-lg">
							<i class="fa-fw fa fa-list"></i> Product list
						</a>

					</div>
					
				</div>
			</div>
		</div>
		<div class="box-content">
			<div class="row">
				<div class="col-lg-12">
					<p class="introtext">Please fill in the information below. The field labels marked with * are required input fields.</p>
				</div>
                <?php if(Session::has('error-message')): ?>
                <p class="alert alert-danger"><?php echo e(Session::get('error-message')); ?></p>
                <?php endif; ?>
				<div class="offset-md-1 col-sm-12 col-md-10 col-xs-10 p-3  border">
					<form method="post" action="<?php echo e(route('admin.product.productSave')); ?>" enctype="multipart/form-data">
						<?php echo csrf_field(); ?>
						<div class="form-row">
							<div class="form-group col-6">
								<label for="formGroupExampleInput2">Supplier<i class="fa-fw fa fa-plus-circle"></i></label>
								<select class="custom-select" name="supplier">
									<?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($supplier->id); ?>"><?php echo e($supplier->company); ?>(<?php echo e($supplier->name); ?>)</option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
							</div>
							<div class="form-group col-6">
								<label>Product Name *</label>
								<input type="text" class="form-control" name="name" placeholder="Product Name">
							</div>
							<div class="form-group col-6">
								<label>Product Code *</label>
							
								<input type="text" class="form-control" name="code" readonly value="<?php echo e($productCode); ?>-<?php echo e($lastId); ?>">
							</div>
							<div class="form-group col-6">
								<label>Starting Inventory</label>
								<input type="number" class="form-control" name="start_inventory" placeholder="Starting Inventory">
							</div>
							<div class="form-group col-6">
								<label for="formGroupExampleInput2">Product Category *</label>
								<select class="custom-select" name="category" id="category">
									<option>Select Category</option>
									<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

								</select>
							</div>
							<div class="form-group col-6">
								<label>Product Sub Category</label>
								<select class="custom-select" name="subcategory" id="subcategory">
									<option value="">Select Subcategory</option>

								</select>
							</div>
							<div class="form-group col-6">
								<label>Product Band</label>
								<select class="custom-select" name="brand">
									<option value="">Select Brand</option>
									<?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($brand->id); ?>"><?php echo e($brand->name); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
							</div>
							<div class="form-group col-6">
								<label>Product Unit</label>
								<select class="custom-select" name="unit">
									<?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($unit->id); ?>"><?php echo e($unit->name); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
							</div>
							<div class="form-group col-6">
								<label>Product Cost *</label>
								<input type="text" class="form-control" name="purchase_price" placeholder="Product Puuchase Price">
							</div>

							<div class="form-group col-6">
								<label for="formGroupExampleInput">Product Price *</label>
								<input type="text" class="form-control" name="sell_price" placeholder="Product Sell Price">
							</div>
							<div class="form-group col-6">
								<label for="formGroupExampleInput">wholesell Price </label>
								<input type="text" class="form-control" name="whole_sell" placeholder="Product whole sell Price">
							</div>
							<div class="form-group col-6">
								<label>Alert Quantity</label>
								<input type="text" class="form-control" name="alert_qty" placeholder="Alert Quantity">
							</div>

							<div class="form-group col-12">
								<label>Product Description</label>
								<textarea class="form-control" name="description" rows="3"></textarea>
							</div>
							<div class="form-group col-6">
								<label for="image">Product Image</label>
								<input type="file" class="form-control" name="image">
							</div>
							<div class="form-group col-12">
								<input type="submit" class="btn btn-primary col-12" value="Add Product">
							</div>





						</div>
					</form>

				</div>

				
			</div>
		</div>
	</div>

</div>
<script>
	$(document).ready(function(){
		$("#category").on('change',function(){
			var catId=$(this).val();
         //ajax

         $.ajax({
         	headers: {
         		'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
         	},
         	url:"<?php echo e(route('admin.subcategory.selectSubcategory')); ?>",
         	type:"POST",
         	data:{'catId':catId},
         	dataType:'json',
         	success:function(data){
         		console.log(data);
         		$('#subcategory').empty();
         		$.each(data,function(index,subcatObj){

         			$("#subcategory").append('<option value ="'+subcatObj.id+'">'+subcatObj.name+'</option>');
         		});

         	},
         	error:function(){
         		alert("error ase");
         	}
         });
     //endajax
 });
	});
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.adminmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/codetree/public_html/project/gripngrease.com.bd/resources/views/admin/modules/product/productAddForm.blade.php ENDPATH**/ ?>