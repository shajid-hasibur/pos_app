<?php $__env->startSection('adminTitle'); ?>
Roles List- Admin Dashboard
<?php $__env->stopSection(); ?>
<?php $__env->startSection('adminContent'); ?>
<?php
use App\Http\Controllers\admin\UserController;
$userCtr=new UserController()
?>
<style>
	.chackbox_style{
		height: 25px;
		width:25px;
	}
</style>
<div class="col-md-12 mt-5 pt-3 border-bottom">
	<div class="text-dark px-0" >
		<p class="mb-1"><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-home"></i> Dashboard / </a><a href="<?php echo e(route('admin.userList')); ?>">Users / </a><a href="<?php echo e(route('admin.users.roles')); ?>">Roles / </a><a href="#" class="active-slink">Change Permission</a><span class="top-date"><?php echo e(date('l, jS F Y')); ?></span></p>

	</div>
</div>

<div class="container-fluid p-3">
	<div class="box">
		<div class="box-header">
			<div class="box-icon-left border-right" style="height:100%">
				
					

					<p class="btn mt-0 task-icon"><i class="fa fa-users"></i></p>
				
			</div>
			<h2 class="blue task-label">Change Permission</h2>

			<div class="box-icon border-left" style="height:100%">
				<div class="dropdown mt-0">
					

					
						<p class="task-btn text_p_primary" title="Actions">
							<i class="fa fa-th-list"></i>
						</p>
						
					
				</div>
			</div>
		</div>
		<div class="box-content">
			<div class="row">
				<div class="col-lg-12">
					<p class="introtext">Please use the table below to navigate or filter the results. You can download the table as excel and pdf.</p>
                   <div class="col-12">
                   	<center>
                   		
                   		<h1><?php echo e($roleInfo->name); ?></h1>
                   	</center>
                   	
                   </div>
                   <form method="post" action="<?php echo e(route('admin.user.role.updatepermission')); ?>">
                    <div class="row">       	
                    		<?php echo csrf_field(); ?>
                    	<p class="btn btn-primary col-12 mt-4" style="border-radius: 0px;">Permissions List</p>
                    	<input type="hidden" name="role_id" value="<?php echo e($roleInfo->id); ?>">
                    	
                    	<?php $__currentLoopData = $allPermission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all_permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                    	
                    	<?php
                        $permission=$userCtr->getpermission($roleInfo->id,$all_permission->id);
                    	?>
                    	<?php if($permission==1): ?>
                    	<div class="col-3">
						<div class="form-check">
						  <input class="form-check-input chackbox_style" type="checkbox" value="<?php echo e($all_permission->id); ?>" name="permission[]" checked="">
						  <label class="form-check-label ml-2 mt-0" style="font-weight: normal;font-size: 20px;"><?php echo e($all_permission->name); ?></label>
						</div>
                    	</div>
                    	<?php else: ?>
                       <div class="col-3">
						<div class="form-check">
						  <input class="form-check-input chackbox_style" type="checkbox" value="<?php echo e($all_permission->id); ?>" name="permission[]">
						  <label class="form-check-label ml-2 mt-0" style="font-weight: normal;font-size: 20px;"><?php echo e($all_permission->name); ?></label>
						</div>
                    	</div>                    	
                    	<?php endif; ?>
                    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    	
                   	  <input type="submit" class="btn  bg_secondary_teal col-12 mt-3" value="Update Permission" style="border-radius: 0px;">
                   	
                   </div>
					</form>	
				</div>
			</div>
		</div>
	</div>

</div>

</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.adminmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp2\htdocs\brac_24_8_2022_h\resources\views/admin/modules/people/users/changepermissions.blade.php ENDPATH**/ ?>