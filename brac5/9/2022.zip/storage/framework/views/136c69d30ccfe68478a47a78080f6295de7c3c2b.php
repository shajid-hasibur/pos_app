      
      <?php if(!empty($customerInfo)): ?>
      <style>
        .bill-p{
          margin-bottom: 0px;
          font-size:14px;
          font-weight: 500;
        }
        .company_name{
          margin-bottom: 0px;
          font-weight: 500;
          font-size:25px;
        }
      </style>
       <div style="text-align: center;">
         <h1 class="company_name"><?php echo e($system->siteName); ?></h1>
         <p class="bill-p"><?php echo e($system->siteEmail); ?></p>
         <p class="bill-p"><b><?php echo e($system->sitePhone); ?></b></p>
         <p class="bill-p">Invoice Id:6751371</p>
       </div>
       <div>
         <p class="bill-p">Customer Name: <?php echo e($customerInfo->name); ?></p>
         <p class="bill-p">Mobile: <?php echo e($customerInfo->mobile); ?></p>
         <br>
       </div>
       <div>
         <table class="table table-bordered">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Item</th>
      <th scope="col">Qty</th>
      <th scope="col">Price</th>
      <th scope="col">Total</th>
    </tr>
  </thead>
  <tbody>
     <?php
        $total_price=0;
        $total_product=0;
        $counter=0;
        ?>
        <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
        $counter++;
        $total_price+=$product->subtotal;
        $total_product+=$product->qty;
        ?>
    <tr>
      <td><?php echo e($counter); ?></td>
      <td><?php echo e($product->name); ?></td>
      <td><?php echo e($product->qty); ?></td>
      <td><?php echo e(number_format($product->price)); ?></td>
      <td style="text-align: right;"><?php echo e(number_format($product->subtotal)); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td colspan="4"><b>Total</b></td>
      <td style="text-align: right;"><?php echo e(Cart::subtotal()); ?></td>
    </tr>
    <tr>
      <td colspan="4"><b>Discount</b></td>
      <td style="text-align: right;"><?php echo e(Cart::discount()); ?></td>
    </tr>
    <tr>
      <td colspan="4"><b>Tax</b></td>
      <td style="text-align: right;"><?php echo e(Cart::tax()); ?></td>
    </tr>
    <tr>
      <td colspan="4"><b>Grand Total</b></td>
      <td style="text-align: right;"><b><?php echo e(Cart::total()); ?></b></td>
    </tr>
   
  </tbody>
</table>
<br>
       </div>

       <div>
         <p class="bill_p" style="font-size: 12px;">Thanks for shopping with us</p>
         <br>
       </div>
       <div style="text-align: center;">
         <p class="bill_p" style="font-size: 12px;font-weight: bold;">Pewered By www.codetreebd.com</p>
       </div>
       <?php else: ?>
       <p>Please select a customer</p>
       <?php endif; ?><?php /**PATH D:\xampp2\htdocs\brac\resources\views/admin/modules/pos/billPreview.blade.php ENDPATH**/ ?>