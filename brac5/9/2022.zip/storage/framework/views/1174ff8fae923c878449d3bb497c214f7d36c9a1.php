<?php $__env->startSection('adminTitle'); ?>
Low Stock Products- Admin Dashboard
<?php $__env->stopSection(); ?>
<?php $__env->startSection('adminContent'); ?>
<?php use App\Http\Controllers\admin\StockController;

?>
<div class="col-md-12 mt-5 pt-3 border-bottom">
	<div class="text-dark px-0" >
		<p class="mb-1"><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-home"></i> Dashboard / </a><a href="<?php echo e(route('admin.productList')); ?>">Products /</a> <a href="" class="active-slink">Low Stock Products</a><span class="top-date"><?php echo e(date('l, jS F Y')); ?></span></p>

	</div>
</div>

<div class="container-fluid p-3">
	<div class="box">
		<div class="box-header">
			<div class="box-icon-left border-right" style="height:100%">
				<p class="btn mt-0 task-icon"><i class="fa fa-barcode"></i></p>
			</div>
			<h2 class="blue task-label">Low Stock Products</h2>

			<div class="box-icon border-left" style="height:100%">
				<div class="dropdown mt-0">
					

					
					<p class="task-btn text_p_primary" title="Actions">
						<i class="fa fa-th-list"></i>
					</button>
					
				</div>
			</div>
		</div>
		<div class="box-content">
			<div class="row">
				<div class="col-lg-12">
					<p class="introtext mb-0">Please use the table below to navigate or filter the results. You can download the table as excel and pdf.</p>

					<table class="table table-bordered table-hover">
						<thead class="bg_p_primary">
							<tr>
								<th class="font-weight-bold" scope="col">#</th>
								<th class="font-weight-bold" scope="col">Image</th>
								<th class="font-weight-bold" scope="col">Name</th>
								<th class="font-weight-bold" scope="col">Code</th>
								<th class="font-weight-bold" scope="col">Brand</th>
								<th class="font-weight-bold" scope="col">Supplier</th>
								<th class="font-weight-bold" scope="col">Cost</th>
								<th class="font-weight-bold" scope="col">Price</th>
								<th class="font-weight-bold" scope="col">Unit</th>
								<th class="font-weight-bold" scope="col">Alert Quantity</th>
								<th class="font-weight-bold" scope="col">Stock</th>
								<th class="font-weight-bold" scope="col">Actions</th>

							</tr>
						</thead>
						<tbody>
							<?php $counter=0;?>
							<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php 
							$stock=StockController::stock($product->id);
							?>
							<?php if($stock<$product->alert_qty): ?>
							<?php $counter++;?>
							<tr>
								<td><?php echo e($counter); ?></td>
								<td>
									<?php if(!empty($product->image)): ?>
									<img src="<?php echo e(asset('/')); ?><?php echo e($product->image); ?>" alt="<?php echo e($product->name); ?>" class="img-rounded" style="width:35px;height:35px;">
									<?php else: ?>
									
									<img src="<?php echo e(asset('/')); ?>public/admin/defaultIcon/no_image.png" alt="No-image" class="img-rounded" style="width:35px;height:35px;">

									<?php endif; ?>
								</td>
								<td><?php echo e($product->name); ?></td>
								<td><?php echo e($product->code); ?></td>
								<td><?php echo e($product->brandInfo['name']); ?></td>
								<td title="Company-<?php echo e($product->supplierInfo['company']); ?>, Mobile- <?php echo e($product->supplierInfo['mobile']); ?>"><?php echo e($product->supplierInfo['name']); ?></td>
								<td style="text-align: right;"><?php echo e(number_format($product->purchase_price)); ?></td>
								<td style="text-align: right;"><?php echo e(number_format($product->sell_price)); ?></td>
								<td><?php echo e($product->unitInfo['name']); ?></td>
								
								<td style="text-align: right;"><?php echo e($product->alert_qty); ?></td>
								<td style="text-align: right;">
									<?php if($stock<$product->alert_qty && $stock >0): ?>
									<p class="badge badge-warning"><?php echo e($stock); ?></p>
									<?php elseif($stock <=0): ?>
									<p class="badge badge-danger"><?php echo e($stock); ?></p>
									<?php else: ?>
									<p class="badge  bg_secondary_teal"><?php echo e($stock); ?></p>
									<?php endif; ?>
								</td>
								<td style="width:120px;">
									<div class="dropdown" style="width:90px;float:right;">
										
										
										<a href="<?php echo e(route('admin.stock.lowStock.addStock',$product->id)); ?>" class="action-btn px-1">
											Add Stock
										</a>
										
									</div>
								</td>
							</tr>
							<?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
					<br>
					
				</div>
			</div>
		</div>
	</div>

</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.adminmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/codetree/public_html/gripngrease.com.bd/resources/views/admin/modules/product/lowStockProduct.blade.php ENDPATH**/ ?>