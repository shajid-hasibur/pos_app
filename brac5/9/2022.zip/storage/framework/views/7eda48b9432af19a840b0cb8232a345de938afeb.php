<?php $__env->startSection('adminTitle'); ?>
Barcode- Admin Dashboard
<?php $__env->stopSection(); ?>
<?php $__env->startSection('adminContent'); ?>
<style>
	.barcode-p{
		text-transform: uppercase;
	}
</style>
<div class="col-md-12 mt-5 pt-3 border-bottom">
	<div class="text-dark px-0" >
		<p class="mb-1"><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-home"></i> Dashboard / </a><a href="<?php echo e(route('admin.productList')); ?>">Products / </a><a href="<?php echo e(route('admin.printBarcode')); ?>">Print Barcode / </a><a>Barcode</a> <span class="top-date"><?php echo e(date('l, jS F Y')); ?></span></p>

	</div>
</div>

<div class="container-fluid p-3">
	<div class="box">
		<div class="box-header">
			<div class="box-icon-left border-right" style="height:100%">
				


				<p class="btn mt-0 task-icon"><i class="fa fa-barcode"></i></p>
				
			</div>
			<h2 class="blue task-label">Print Barcode/Label</h2>

			<div class="box-icon border-left" style="height:100%">
				<div class="dropdown mt-0">
					

					
					<p class="task-btn text_p_primary" title="Actions">
						<i class="fa fa-th-list"></i>
					</p>
					
					
				</div>
			</div>
		</div>
		<div class="box-content">
			<div class="row">
				<div class="col-lg-12">
					<p class="introtext">Please use the table below to navigate or filter the results. You can download the table as excel and pdf.</p>
					<p class="col-12 btn btn-primary" style="border-radius:0px;cursor:pointer;" onclick="printContent('barcode')">Print</p>
					<div class="barcode-print" id="barcode">

						<?php for($i=0;$i<$qty;$i++): ?>
						<div class="barcode p-2" style="text-align:center;border:1px dotted gray;width:200px;height:auto;margin:2px;float: left;">
							<h4 class="mb-0 barcode-p"><b><?php echo e($siteName); ?></b></h4>
							<h4 class="mb-0 barcode-p"><?php echo e($productName); ?></h4>
							<h4 class="mb-0"><?php echo e($productPrice); ?></h4>
						<img src="data:image/png;base64,<?php echo e(base64_encode($barcode)); ?>">
						<h4 class="mb-0"><b><?php echo e($proid); ?></b></h4>
						</div>
						<?php endfor; ?>
					</div>
					
					
				</div>
			</div>
		</div>
	</div>

</div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.adminmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/codetree/public_html/gripngrease.com.bd/resources/views/admin/modules/product/barcode.blade.php ENDPATH**/ ?>