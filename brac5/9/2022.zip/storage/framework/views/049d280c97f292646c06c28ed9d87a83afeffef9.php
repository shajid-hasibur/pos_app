<?php $__env->startSection('adminTitle'); ?>
Add New Promotion- Admin Dashboard
<?php $__env->stopSection(); ?>
<?php $__env->startSection('adminContent'); ?>
<style>
    label {
        font-weight: bold;
    }

    input['text'] {
        border-radius: 0px;
    }
</style>
<!-- date time picker -->

<div class="col-md-12 mt-5 pt-3 border-bottom">
    <div class="text-dark px-0">
        <p class="mb-1"><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-home"></i> Dashboard / </a><a href="<?php echo e(route('admin.product.promotionlist')); ?>">Promotion / </a><a class="active-slink">Promotion Add</a> <span class="top-date"><?php echo e(date('l, jS F Y')); ?></span></p>

    </div>
</div>

<div class="container-fluid p-3">
    <div class="box">
        <div class="box-header">
            <div class="box-icon-left border-right" style="height:100%">



                <p class="btn mt-0 task-icon"><i class="fa fa-barcode"></i></p>

            </div>
            <h2 class="blue task-label">Add New Promotion</h2>

            <div class="box-icon border-left" style="height:100%">
                <div class="dropdown mt-0">



                    <p class="task-btn text_p_primary text_p_primary" title="Actions">
                        <i class="fa fa-th-list"></i>
                        </button>
                    <div class="task-menu p-2">
                        <a class="dropdown-item pl-0" type="button" data-toggle="modal" data-target=".bd-example-modal-lg">
                            <i class="fa-fw fa fa-list"></i> Promotion list
                        </a>

                    </div>

                </div>
            </div>
        </div>
        <div class="box-content">
            <div class="row">
                <div class="col-lg-12">
                    <p class="introtext">Please fill in the information below. The field labels marked with * are required input fields.</p>
                </div>
                <?php if(Session::has('error-message')): ?>
                <p class="alert alert-danger"><?php echo e(Session::get('error-message')); ?></p>
                <?php endif; ?>
                <div class="offset-md-1 col-sm-12 col-md-10 col-xs-10 p-3  border">
                    <form method="post" action="<?php echo e(route('admin.product.promotionSave')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-row">
                            <div class="form-group col-6">
                                <label>Promotion Name *</label>
                                <input type="text" class="form-control" name="promotion_name" placeholder="promotion Name">
                            </div>
                            <div class="form-group col-6">
                                <label for="formGroupExampleInput2">Category Name <i class="fa-fw fa fa-plus-circle"></i></label>
                                <select class="custom-select" name="promotion_category_name">
                                    <option value="">Please Select Category</option>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->name); ?>"><?php echo e($category->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group col-6">
                                <label for="formGroupExampleInput2">Sub Category Name <i class="fa-fw fa fa-plus-circle"></i></label>
                                <select class="custom-select" name="promotion_subcategory_name">
                                    <option value="">Please Select Sub Category</option>
                                    <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($subcategory->name); ?>"><?php echo e($subcategory->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group col-6">
                                <label for="formGroupExampleInput2">Product Name * <i class="fa-fw fa fa-plus-circle"></i></label>
                                <select class="custom-select" name="Promotion_product">
                                    <option value="">Please Select product</option>
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($product->name); ?>"><?php echo e($product->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group col-6">
                                <label for="formGroupExampleInput2">Product Code * <i class="fa-fw fa fa-plus-circle"></i></label>
                                <select class="custom-select" name="Promotion_product_code">
                                    <option value="">Please Select Product Code</option>
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($product->code); ?>"><?php echo e($product->code); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group col-6" >
                                <label>Starting Duration</label>
                                <input type="date" class="form-control" name="promotion_start_duration" placeholder="Starting Time">
                            </div>
                            <div class="form-group col-6">
                                <label>Ending Duration</label>
                                <input type="date" class="form-control" name="promotion_end_duration" placeholder="Ending Time">

                            </div>
                            <div class="form-group col-6">
                                <label>Promotion Price*</label>
                                <input type="number" class="form-control" name="promotion_ammount" placeholder="promotion  Price">
                            </div>

                            <div class="form-group col-6">
                                <label for="formGroupExampleInput2">Status <i class="fa-fw fa fa-plus-circle"></i></label>
                                <select class="custom-select" name="status">
                                    <option value="Active">Active</option>
                                    <option value="Inactive">Inactive</option>
                                </select>
                            </div>
                            <div class="form-group col-12">
                                <input type="submit" class="btn bg_p_primary col-12" value="Add Product">
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

</div>
<!-- <script type="text/javascript">
$(function(){
$('#datetimepicker').datetimepicker();
});
</script> -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.adminmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp2\htdocs\brac_24_8_2022_h\resources\views/admin/modules/promotion/add_promotion.blade.php ENDPATH**/ ?>