<?php $__env->startSection('adminTitle'); ?>
Attendence
<?php $__env->stopSection(); ?>
<?php $__env->startSection('adminContent'); ?>
<header class="d-flex justify-content-between align-items-center">
        <div class="p-4 align-self-start">
            <img src="logo.png" alt="" width="100">
        </div>
        <div class="text-center pe-4">
            <h3 class="">
                Employee Attendence System
            </h3>
        </div>
    </header>

    <section>
        <div class="date-box p-3 border m-4">
            <h2 class="text-center">Date: <?php echo e($date); ?></h2>
        </div>
      <div class="mx-5">
      <table class="table table-striped  " >
            <thead>
              <tr>
                <th scope="col">S/l</th>
                <th scope="col">Employee Name</th>
                <th scope="col">Employee ID</th>
                <th scope="col">Attendence</th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $attendence; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$att): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <th scope="row"><?php echo e($key +1); ?></th>
                <td><?php echo e($att->name); ?></td>
                <td><?php echo e($att->emp_id); ?></td>
                <td> 
                    <!-- <input type="radio" name="attendence1" id="p1" name="a[">
                    <label for="p1">P</label>
                    <input type="radio" name="attendence1" id="a1" name="a">
                    <label for="a1">A</label> -->
                    <select class="form-select form-select-lg mb-3" aria-label=".form-select-lg example" name="attendence"> 
                      <option value="1">Present</option>
                      <option value="0">Absent</option> 
                    </select>

 
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
      </div>
          <div class="text-center mt-5">
          <input type="submit" class="btn bg_p_primary" value="Submit">
          </div>
    </section>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>


<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">Close</button>
      </div>
      <div class="modal-body">
      <form class="row g-3" action="<?php echo e(route('admin.add_attendence')); ?>" method="POST">
        <?php echo csrf_field(); ?>
          <div class="col-md-6">
            <label for="ename" class="form-label">Employee Name</label>
            <input type="text" class="form-control" id="ename" name="ename">
          </div>
          <div class="col-md-6">
            <label for="eID" class="form-label">Employee ID</label>
            <input type="text" class="form-control" id="eID" name="eID">
          </div>
          
            
          <div class="col-md-6">
            <label for="e_S_Date" class="form-label">Employee Starting Date</label>
            <input type="date" class="form-control" id="e_S_Date" name="e_S_Date">
          </div>
            
          <!-- <div class="col-md-6">
            <label for="e_role" class="form-label">Employee Role</label>
            <input type="text" class="form-control" id="e_role" name="e_role">
          </div> -->
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Add</button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.adminmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp2\htdocs\brac_24_8_2022_h\resources\views/admin/modules/attendence.blade.php ENDPATH**/ ?>