<div class="modal-header">
				<h2 class="modal-title" id="exampleModalLabel">Store Details</h2>
				<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
			</div>
			<div class="modal-body">
				    <p><b>Store code:</b> {{$store->code}}</p>
					<p><b>Store Name:</b> {{$store->name}}</p>
					<p><b>Store email:</b> {{$store->email}}</p>
					<p><b>Store phone:</b> {{$store->phone}}</p>
					<p><b>Store address:</b> {{$store->address}}</p>
					

				</div>
				<div class="modal-footer">
				</div>