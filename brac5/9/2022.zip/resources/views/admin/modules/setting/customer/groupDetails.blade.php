    	<div class="modal-header">
        <h2 class="modal-title" id="exampleModalLabel">Customer Group Details</h2>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
       <div class="modal-body">

          <p><b>Name :</b>{{$group->name}}</p>
          <p><b>Percentage: </b>{{$group->percentage}}</p>
          
       
      </div>
      