@extends('admin.layouts.adminmaster')
@section('adminTitle')
POS
@stop
@section('adminContent')
    

	
@stop