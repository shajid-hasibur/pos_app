@extends('admin.layouts.adminmaster')
@section('adminTitle')
Quantity Adjustment- Admin Dashboard
@stop
@section('adminContent')
    

	
@stop