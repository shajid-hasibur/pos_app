<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SalesDueReturn extends Model
{
    //
}
