<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class promocode extends Model
{
    //
}
