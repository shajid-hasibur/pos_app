<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePromotionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('promotions', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('promotion_name');
            $table->string('promotion_category_name');
            $table->string('promotion_subcategory_name');
            $table->dateTime('promotion_start_duration');
            $table->dateTime('promotion_end_duration');
            $table->bigInteger('promotion_ammount');
            $table->string('promotion_product');
            $table->string('promotion_product_code');
            $table->bigInteger('status')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('promotions');
    }
}
